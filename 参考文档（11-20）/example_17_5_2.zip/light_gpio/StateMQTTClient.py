from umqtt.simple import MQTTClient

class StateMQTTClient(MQTTClient):

    def __init__(self, client_id, server, port=0, user=None, password=None, keepalive=0, ssl=False, ssl_params={}):
        if user=='':
            user = None
            password = None
        super().__init__(client_id, server, port, user, password, keepalive, ssl, ssl_params)
        self._connected = False

    def connect(self, clean_session=True):
        try:
            self._connected = True
            return super().connect(clean_session)
        except:
            self._connected = False

    def publish(self, topic, msg, retain=False, qos=0):
        try:
            return super().publish(topic, msg, retain, qos)
        except:
            self._connected = False

    def check_msg(self):
        try:
            self.sock.setblocking(False)
            return self.wait_msg2()
        except:
            self._connected = False

    def ping(self):
        try:
            return super().ping()
        except:
            self._connected = False

    def disconnect(self):
        try:
            self._connected = False
            return super().disconnect()
        except:
            self._connected = False

    def wait_msg2(self):
        res = self.sock.read(1)
        self.sock.setblocking(True)
        if res is None:
            return None
        if res == b"":
            raise OSError(-1)
        if res == b"\xd0":  # PINGRESP
            sz = self.sock.read(1)[0]
            assert sz == 0
            return 1
        op = res[0]
        if op & 0xf0 != 0x30:
            return op
        sz = self._recv_len()
        topic_len = self.sock.read(2)
        topic_len = (topic_len[0] << 8) | topic_len[1]
        topic = self.sock.read(topic_len)
        sz -= topic_len + 2
        if op & 6:
            pid = self.sock.read(2)
            pid = pid[0] << 8 | pid[1]
            sz -= 2
        msg = self.sock.read(sz)
        self.cb(topic, msg)
        if op & 6 == 2:
            pkt = bytearray(b"\x40\x02\0\0")
            struct.pack_into("!H", pkt, 2, pid)
            self.sock.write(pkt)
        elif op & 6 == 4:
            assert 0


    @property
    def connected(self):
        return self._connected
