import json
import network
import time
from ubinascii import hexlify
from machine import Pin, unique_id, Signal
from StateMQTTClient import StateMQTTClient

# 连接的GPIO口
PIN_LIGHT = 13
INVERT = False

# 读取配置文件
with open( 'config.json' ) as f:
    CONFIG = json.loads(f.read())
    print("Load Config: {b}".format(b=CONFIG))


# MQTT主题
DEVICE_NAME = 'SimepleLight_' + hexlify(unique_id()).decode()

BASE_TOPIC = 'hachina/sensor/' + DEVICE_NAME
AVAILABILITY_TOPIC = BASE_TOPIC + "/availability"
STATE_TOPIC = BASE_TOPIC + "/state"
COMMAND_TOPIC = BASE_TOPIC + "/command"


# MQTT自动配置
DISCOVERY_CONFIG_TOPIC = 'homeassistant/light/' + DEVICE_NAME + '/config'
DISCOVERY_CONFIG_DATA_SCHEMA = """
{"name": "%s",
"command_topic": "%s",
"state_topic": "%s",
"availability_topic": "%s"
}
"""
DISCOVERY_CONFIG_DATA = DISCOVERY_CONFIG_DATA_SCHEMA % (DEVICE_NAME,
                                                        COMMAND_TOPIC,
                                                        STATE_TOPIC,
                                                        AVAILABILITY_TOPIC
                                                        )
def mqtt_cb(topic, msg):

    global mqtt, light

    print((topic, msg))
    if topic==COMMAND_TOPIC.encode():
        if msg == b"ON":
            light.on()
        elif msg == b"OFF":
            light.off()
        mqtt.publish( STATE_TOPIC,
                      b"ON" if light.value() else b"OFF",
                      retain=True )


def init():

    global mqtt, light
    
    # Light init
    light = Signal(Pin(PIN_LIGHT, Pin.OUT), invert=INVERT)

    # wifi init
    ap_if = network.WLAN(network.AP_IF)
    sta_if = network.WLAN(network.STA_IF)
    ap_if.active(False)
    sta_if.active(True)
    sta_if.connect(CONFIG.get("wifi_ssid"),
                   CONFIG.get("wifi_password")
                   )
    time.sleep(10)
    if sta_if.isconnected():
        print("WIFI connected")
    else:
        print("Can't connect to WIFI")
        return False

    # MQTT init
    mqtt = StateMQTTClient(client_id=DEVICE_NAME,
                           server=CONFIG.get("mqtt_server"),
                           port=CONFIG.get("mqtt_port"),
                           user=CONFIG.get("mqtt_user"),
                           password=CONFIG.get("mqtt_password"),
                           keepalive=60)
    mqtt.set_last_will( AVAILABILITY_TOPIC, b"offline", retain=True)
    mqtt.set_callback(mqtt_cb)
    mqtt.connect()
    if mqtt.connected:
        print("MQTT connected")
        mqtt.subscribe(COMMAND_TOPIC)
        mqtt.publish( DISCOVERY_CONFIG_TOPIC, DISCOVERY_CONFIG_DATA.encode(), retain=True)
        mqtt.publish( AVAILABILITY_TOPIC, b"online", retain=True)
        mqtt.publish( STATE_TOPIC,
                      b"ON" if light.value() else b"OFF",
                      retain=True )
    else:
        print("Can't connect to MQTT Broker")
        return False

    return True

def start():

    global mqtt, light_sensor

    while init()==False:
        time.sleep(10)

    last_pong_time = time.time()
    last_ping_time = 0
    while True:
        now = time.time()
        if mqtt.connected:
            if mqtt.check_msg()==1:
                last_pong_time = now

            # 如果20秒未收到反馈
            if now-last_pong_time > 20:
                mqtt.disconnect()
                continue

            # 每8秒Ping一次
            if now-last_ping_time > 8:
                mqtt.ping()
                last_ping_time = time.time()
        else:
            mqtt.connect()
            if mqtt.connected:
                print("MQTT connected")
                mqtt.subscribe(COMMAND_TOPIC)
                mqtt.publish( DISCOVERY_CONFIG_TOPIC, DISCOVERY_CONFIG_DATA.encode(), retain=True)
                mqtt.publish( AVAILABILITY_TOPIC, b"online", retain=True)
                mqtt.publish( STATE_TOPIC,
                              b"ON" if light.value() else b"OFF",
                              retain=True )
                last_pong_time = time.time()
            else:
                print("Can't connect to MQTT Broker")
                time.sleep(10)


    mqtt.disconnect()
