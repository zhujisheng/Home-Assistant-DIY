import tsl2561
import json
import network
import time
from ubinascii import hexlify
from machine import I2C, Pin, unique_id
from umqtt.robust import MQTTClient


# 连接的GPIO口
PIN_SDA = 13
PIN_SCL = 12

# 读取配置文件
with open( 'config.json' ) as f:
    CONFIG = json.loads(f.read())
    print("Load Config: {b}".format(b=CONFIG))


# MQTT主题
DEVICE_NAME = 'LightSensor_' + hexlify(unique_id()).decode()

BASE_TOPIC = 'hachina/sensor/' + DEVICE_NAME
AVAILABILITY_TOPIC = BASE_TOPIC + "/availability"
STATE_TOPIC = BASE_TOPIC + "/state"


# MQTT自动配置
DISCOVERY_CONFIG_TOPIC = 'homeassistant/sensor/' + DEVICE_NAME + '/config'
DISCOVERY_CONFIG_DATA_SCHEMA = """
{"name": "%s",
"state_topic": "%s",
"availability_topic": "%s",
"device_class": "illuminance",
"unit_of_measurement": "lux"
}
"""
DISCOVERY_CONFIG_DATA = DISCOVERY_CONFIG_DATA_SCHEMA % (DEVICE_NAME,
                                                        STATE_TOPIC,
                                                        AVAILABILITY_TOPIC
                                                        )



def init():

    global mqtt, light_sensor
    
    # tsl2561 init
    i2c = I2C(scl=Pin(PIN_SCL), sda=Pin(PIN_SDA))
    light_sensor = tsl2561.TSL2561(i2c)

    # wifi init
    ap_if = network.WLAN(network.AP_IF)
    sta_if = network.WLAN(network.STA_IF)
    ap_if.active(False)
    sta_if.active(True)
    sta_if.connect(CONFIG.get("wifi_ssid"),
                   CONFIG.get("wifi_password")
                   )
    time.sleep(10)
    if sta_if.isconnected():
        print("WIFI connected")
    else:
        print("Can't connect to WIFI")
        return False

    # MQTT init
    mqtt = MQTTClient(client_id=DEVICE_NAME,
                      server=CONFIG.get("mqtt_server"),
                      port=CONFIG.get("mqtt_port"),
                      user=CONFIG.get("mqtt_user"),
                      password=CONFIG.get("mqtt_password"),
                      keepalive=60)
    mqtt.set_last_will( AVAILABILITY_TOPIC, b"offline", retain=True)
    try:
        mqtt.connect()
        print("MQTT connected")
        mqtt.publish( DISCOVERY_CONFIG_TOPIC, DISCOVERY_CONFIG_DATA.encode(), retain=True)
        mqtt.publish( AVAILABILITY_TOPIC, b"online", retain=True)
    except OSError as e:
        print("Can't connect to MQTT Broker: %r" % e)
        return False

    return True


def start():

    global mqtt, light_sensor

    while init()==False:
        time.sleep(10)

    while True:
        lux = light_sensor.read()
        mqtt.publish( STATE_TOPIC, str(lux).encode(), retain=True)
        print("Get Value: %f" % lux)
        time.sleep(20)
